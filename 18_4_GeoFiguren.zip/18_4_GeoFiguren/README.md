# GeoFiguren
Im vorliegenden Projekt sollen die Flächeninhalte und Umfänge geometrischer Figuren
berechnet werden. 
